package com.reshu;

public class Employee {
	private int empid;
	private String ename;
	private int dept_no;
	private String job;
	private double sal;
	
	public Employee(int empid,String ename,int dept_no,String job,double sal) {
		this.empid=empid;
		this.ename=ename;
		this.dept_no=dept_no;
		this.job=job;
		this.sal=sal;
		
	}

	
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public int getDept_no() {
		return dept_no;
	}
	public void setDept_no(int dept_no) {
		this.dept_no = dept_no;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public double getSal() {
		return sal;
	}
	public void setSal(double sal) {
		this.sal = sal;
	}

}
