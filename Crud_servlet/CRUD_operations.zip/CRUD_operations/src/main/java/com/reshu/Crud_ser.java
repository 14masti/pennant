package com.reshu;

import java.io.BufferedReader;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@WebServlet("/Crud_ser")
public class Crud_ser extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public Crud_ser() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		EmpDAL e = new EmpDAL();
		try {
			e.getConnection();
			JSONArray data = e.read();
			response.getWriter().println(data.toString());
		} catch (Exception a) {
			a.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		String action = request.getParameter("action");
		
		EmpDAL e = new EmpDAL();
		    
		        // Read the JSON data from the request body
		        BufferedReader reader = request.getReader();
		       
		        StringBuilder jsonData = new StringBuilder();
		        String line;
		        while ((line = reader.readLine()) != null) {
		            jsonData.append(line);
		        }

		        try {
		            // Parse the JSON data
		            JSONObject jsonObject = new JSONObject(jsonData.toString());
		            if ("add".equals(action)) {
		            // Retrieve values from the JSON object
		            int empid = jsonObject.getInt("empid");
		            String ename = jsonObject.getString("ename");
		            String job = jsonObject.getString("job");
		            int dept_no = jsonObject.getInt("dept_no");
		            double sal = jsonObject.getDouble("sal");

		            // Call a method to insert the data into the database
		            boolean success = e.addEmployee(empid, ename, job, dept_no, sal);

		            // Send a response back to the frontend indicating success or failure
		            response.setContentType("text/plain");
		            if (success) {
		                response.getWriter().write("Record added successfully");
		            } else {
		                response.getWriter().write("Failed to add record");
		            }
		            }
		            }catch (JSONException e1) {
		            // Handle JSON parsing exceptions here
		            response.setContentType("text/plain");
		            response.getWriter().write("Error parsing JSON data");
		        }
		            
		    
}
}
