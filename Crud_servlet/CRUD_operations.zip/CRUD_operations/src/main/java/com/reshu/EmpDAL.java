
package com.reshu;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;

public class EmpDAL{
	Connection conn;
	ResultSet rst;

	String qry, cs;

	public Connection getConnection() {
        try {
        	String url="jdbc:postgresql://localhost:5432/postgres";
    		String user="postgres";
    		String password="#Mastani14";

            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(url, user, password);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conn;
    }
	

	public JSONArray read() throws SQLException, JSONException {
		PreparedStatement pre = conn.prepareStatement("select * from reshu_emp");

		ResultSet rst = pre.executeQuery();
		JSONArray j = new JSONArray();
		while (rst.next()) {
			JSONObject obj = new JSONObject();
			obj.put("id", rst.getInt(1));
			obj.put("name", rst.getString(2));
			obj.put("job", rst.getString(3));
			obj.put("dep", rst.getInt(8));
			obj.put("salary", rst.getDouble(6));
			j.put(obj);
		}
		return j;
	}
	
	
	boolean addEmployee(int empid, String ename, String job, int dept_no, double sal) {
	    
	    PreparedStatement preparedStatement = null;
	    
	    try {
	        // Establish a database connection
	        conn = getConnection(); // Implement your getConnection() method
	        
	        // SQL query to insert data
	        String insertQuery = "INSERT INTO reshu_emp (empid, ename, job, dept_no, sal) VALUES (?, ?, ?, ?, ?)";
	        
	        // Create a PreparedStatement
	        preparedStatement = conn.prepareStatement(insertQuery);
	        preparedStatement.setInt(1, empid);
	        preparedStatement.setString(2, ename);
	        preparedStatement.setString(3, job);
	        preparedStatement.setInt(4, dept_no);
	        preparedStatement.setDouble(5, sal);
	        
	        // Execute the query
	        int rowsAffected = preparedStatement.executeUpdate();
	        
	        return rowsAffected > 0; // Return true if insertion is successful
	    } catch (SQLException e) {
	        e.printStackTrace();
	        // Handle the exception or log the error
	    } finally {
	        // Close the resources
	        if (preparedStatement != null) {
	            try {
	                preparedStatement.close();
	            } catch (SQLException e) {
	                e.printStackTrace();
	            }
	        }
	        
	        if (conn != null) {
	            try {
	                conn.close();
	            } catch (SQLException e) {
	                e.printStackTrace();
	            }
	        }
	    }
	    
	    return false; // Return false if insertion failed
	}
	/*public static void main(String[] args) {
		System.out.println(new EmpDAL().addEmployee(52, "reshu", "fzvsdv", 45, 8585));
	}*/

}
	

